% ʹ��ƽ̨ - Matlab7.0
%by akjuan
%all rights preserved by www.4math.cn
%2008.11

clc
clear
[x,y]=meshgrid(-10:.5:10);
f= 8*x-4*y +x.^2+3*y.^2;
surfc(x,y,f)

x0=[0,0];


%[x,fval,exitflag]=fminunc(@(x)(8*x(1)-4*x(2) +x(1).^2+3*x(2).^2),x0)
 options=optimset('display','iter','Tolx',1e-8);
[x,fval,exitflag]=fminunc(@(x)(8*x(1)-4*x(2) +x(1).^2+3*x(2).^2),x0,options)
 [x_fminsearch,fval_fminsearch,exitflag]=fminsearch(@(x)(8*x(1)-4*x(2) +x(1).^2+3*x(2).^2),x0,options)