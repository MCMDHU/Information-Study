% ʹ��ƽ̨ - Matlab7.0
%by akjuan
%all rights preserved by www.4math.cn
%2008.11

clc
clear
       
       f=[-70 -120];
       A=[9 4;4 5;3 10];
       B=[3600;2000;3000];
       Aeq=[];  Beq=[];
       lb=[0 0];ub=[inf inf];
        x0=[1 1];
       options=optimset('display','iter','Tolx',1e-8);

     [x,f,exitflag]=linprog(f,A,B,Aeq,Beq,lb,ub,x0,options)
     %[xmincon,fval,exitflag,output] = fmincon(@(x)-(70*x(1)+120*x(2)),x0,A,B,Aeq,Beq,lb,ub,[],options)
   