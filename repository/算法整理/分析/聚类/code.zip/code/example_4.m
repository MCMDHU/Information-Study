% ʹ��ƽ̨ - Matlab7.0
%by akjuan
%all rights preserved by www.4math.cn
%2008.11
function example_4_b()
clc
clear


f=@(x)-0.5*(70*x(1)+66*x(2))+0.5*(0.02*x(1)^2+0.01*x(2)^2+0.04*(x(1)+x(2))^2); 



%fun='[-(70*x(1)+66*x(2)),0.02*x(1)^2+0.01*x(2)^2+0.04*(x(1)+x(2))^2]';

x0=[1000,1000];
A=[1 1];
B=5000;
Aeq=[];  Beq=[];
lb=[0 0];ub=[inf inf];
options=optimset('display','iter','Tolx',1e-8);





[x_f,fval_f, exitflag]=fmincon(f,x0,A,B,Aeq,Beq,lb,ub,[],options)


 
 ff1=70*x_f(1)+66*x_f(2)
 ff2=0.02*x_f(1)^2+0.01*x_f(2)^2+0.04*(x_f(1)+x_f(2))^2





