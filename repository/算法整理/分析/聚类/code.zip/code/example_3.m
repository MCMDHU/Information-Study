% ʹ��ƽ̨ - Matlab7.0
%by akjuan
%all rights preserved by www.4math.cn
%2008.11
function example_3()
clear
clc
options=optimset('display','iter','MaxFunEvals',1e5,'MaxIter',1e10,'TolFun',1e-8,'TolX',1e-8);
A=[];
B=[];
AE=[1 2];
BE=[0];
%x0=rand(1,2);
x0=[-1 1];
lb =[ ]; % Lower bounds x >= 0
ub =[ ];         % No upper bounds


[xmincon,fval,exitflag,output] = fmincon(@objfun,x0,A,B,AE,BE,lb,ub,@confun,options)

             
             

function f = objfun(x)

 f=exp(x(1))*(6*x(1)^2+3*x(2)^2+2*x(1)*x(2)+4*x(2)+1);

function [c, ceq] = confun(x)

c=[x(1)*x(2)-x(1)-x(2)+1,-2*x(1)*x(2)-5];
ceq=[];
             

