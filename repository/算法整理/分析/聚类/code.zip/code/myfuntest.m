function f=myfuntest(x)
      f=100.*(x(2)-x(1).^2).^2+(4.5543-x(1)).^2;