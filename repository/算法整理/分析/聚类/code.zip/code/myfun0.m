function f = myfun0(x,a)
f = x(1)^2 + a*x(2)^2;