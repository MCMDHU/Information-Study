a = 1.5;
[x,fval,exitflag]= fminsearch(@(x) myfun0(x,a),[0,1])